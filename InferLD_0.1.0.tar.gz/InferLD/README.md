# LD_Infer
Inferring distributions of linkage disequilibrium from GWAS summary statistics


## Building, testing, documenting, etc

Should be able to build using code like
```
cd /Users/marcustutert/Desktop/Oxford_Dphil/
## or 
cd ~/proj/InferLD
## then
./scripts/build.R
```

Code for more fine grained control
```

pkg <- "/Users/marcustutert/Desktop/Oxford_Dphil/InferLD"
##

pkg <- "~/proj/InferLD/"
devtools::build(pkg = pkg)
devtools::document(pkg)
devtools::load_all(pkg, quiet = FALSE)
package_tarball <- devtools::build(pkg = pkg, manual = TRUE)
install.packages(package_tarball, repos = NULL, type ="source")

devtools::test("/Users/marcustutert/Desktop/Oxford_Dphil/InferLD", reporter = "summary")

```


## R code for profiling

```
## from InferLD repo home
./scripts/profile.R

###To source and see likelihoods run profvis_profile.R file
```

<!-- badges: start -->
[![R-CMD-check](https://github.com/marcustutert/LD_Infer/workflows/R-CMD-check/badge.svg)](https://github.com/marcustutert/LD_Infer/actions)
<!-- badges: end -->

