test_that("Generative Model Non-Recombination No Recombination", {
  library(matrixStats)
  library(plotly)
  print(getwd())
  ref_hap_panel    = read.table("./Data/ref_hap_panel")
  observed_gwas_se = read.table("./Data/observed_gwas_se_generative_drifted")[,1]
  gwas_variants_af = read.table("./Data/gwas_variants_af")[,1]

  r2_true_inferred_af_across_chains = function(inferred_allele_freq, #Matrix across chains
                                               true_allele_freq,
                                               graphic = FALSE,
                                               nhaps,
                                               nSamples){    #Vector of AFs
    nSamples = nSamples
    r2       = c()
    for (i in (1:ncol(inferred_allele_freq))) {
      r2[i] = summary(lm(inferred_allele_freq[,i]~true_allele_freq))$r.squared
    }
    if (graphic == FALSE) {
      return(r2)
    }
    else{
      #Create plot
      fig <- plot_ly(data = iris, x = ~seq(1:ncol(inferred_allele_freq)), y = ~r2)
      fig <- fig %>% layout(title = 'Correlation of True to Inferred Allele Frequency Across Sweeps',
                            xaxis = list(title = 'nSamples (Full Sweeps)'),
                            yaxis = list(title = 'r2 correlation (Inferred~True)'))
      return(fig)
    }
  }

  nSamples = 10
  #Use some generative model data that we have simulated under a model of no genetic drift
  results                             = LD_inference(ref_panel_haplotypes   = ref_hap_panel,
                                                      fst                   = 0.1,
                                                      alpha                 = 1e3,
                                                      nSamples              = nSamples,
                                                      weights_resolution    = 10,
                                                      likelihood_toggle     = TRUE,
                                                      gwas_variance         = observed_gwas_se^0.5,
                                                      case_control_constant = 1,
                                                      debug                 = TRUE)

  r2 = r2_true_inferred_af_across_chains(inferred_allele_freq = results[[3]],
                                    true_allele_freq     = gwas_variants_af,
                                    graphic              = TRUE,
                                    nSamples             = nSamples,
                                    nhaps                = 800)
  print(r2)
  r2_post_burn_in = mean(r2[(.9*length(r2)):length(r2)])
  expect_gt(r2_post_burn_in, 0.95)})

