#' @export
`arraydiag` <- function(x,value){
  #### Diagonal Array Replacement Function ####
  dims <- dim(x)
  id <- seq_len(dims[1]) +
    dims[2]*(seq_len(dims[2])-1)
  id <- outer(id,(seq_len(dims[3])-1)*prod(dims[1:2]),`+`)
  x[c(id)] <- value
  dim(x) <- dims
  x
}

#' @export
Qx_Components = function(HW_Matrix, start, end){

  #Get constants we need
  nsnps       = ncol(HW_Matrix)
  nhaps       = nrow(HW_Matrix)
  flow_length = end - start #Length of genome

  #Create an array that stores the three vectors (A_i = {A_1,A_2,...A}, B_j = {B_1,B_2,...} and the diag([,,]) across the depth of nsnps-1
  Qx_AB = array(rep(NA,nhaps*3*flow_length), dim = c(nhaps,3,flow_length))

  #We will loop over each locus (except for the last one, and store the results into the respective Qx arrays )
  for (i in seq(1,nsnps-1)) {
    #flow leaving i @ x
    delta_i_x   = colMaxs(cbind(c(HW_Matrix[,i]-HW_Matrix[,i+1]),rep(0,nhaps)))
    #flow entering @ x+1
    delta_j_x_1 = colMaxs(cbind(c(HW_Matrix[,i+1]-HW_Matrix[,i]),rep(0,nhaps)))
    #flow normalization constant (w_i^x * sum(delta_j_x_1)), will be different for each i & j
    #Split these up to get the Ai's and Bj's
    w_i           = HW_Matrix[,i]
    delta_x_1     = sum(delta_i_x)
    #Diagonal elements
    diag_elements = colMins(HW_Matrix[,i:(i+1)])/HW_Matrix[,i]
    diag_elements[is.nan(diag_elements)] <- 1


    #Assign this to the Qx_AB vectors
    Qx_AB[,1,i] = delta_i_x/w_i
    Qx_AB[,2,i] = delta_j_x_1/delta_x_1
    Qx_AB[,,i][is.nan(Qx_AB[,,i])] <- 0
    Qx_AB[,3,i] = diag_elements
  }
  return(Qx_AB)
}

#' @export
markovian_flow = function(HW_Matrix, start, end, recombination){
  #Get constants we need
  nhaps       = nrow(HW_Matrix)
  nsnps       = ncol(HW_Matrix)
  #Length of genome that we will be inferring/using for downstream applications
  #Create a 3D array of Q^x matrices that will store the markovian transition flows
  Qx_array = array(rep(0,nhaps*nhaps*(nsnps-1)), dim = c(nhaps,nhaps,(nsnps-1)))

  #Note that if there is NO recombination, the weights along the region will not change
  #As a result the Qx matrices will all be diagonal

  if (recombination == FALSE) {
    Qx_array = `arraydiag`(x = Qx_array ,value = 1)
  }

  else{

    ####### Case 1: i != j, the Non-Diagonal elements of the Q^x array #########

    #We will loop over each locus (except for the last one, and store the results into the respective Qx arrays )
    for (i in seq(1,nsnps-1)) {
      #flow leaving i @ x
      delta_i_x   = apply(cbind(c(HW_Matrix[,i] - HW_Matrix[,i + 1]),rep(0,nhaps)), 1, FUN = max)
      #flow entering @ x+1
      delta_j_x_1 = apply(cbind(c(HW_Matrix[,i + 1]-HW_Matrix[,i]),rep(0,nhaps)), 1, FUN = max)
      #flow normalization constant (w_i^x * sum(delta_j_x_1)), will be different for each i & j
      delta_total = HW_Matrix[,i]*sum(delta_i_x)

      #Caclulate the outer products based on the delta's we calculated above and assign them to the Q^x array
      Qx_array[,,i] = outer(delta_i_x, delta_j_x_1, FUN = '*') %*% diag(1/delta_total)
      #Replace NAN's with 0's
      Qx_array[,,i][is.nan(Qx_array[,,i])] <- 0
    }

    ###### Case 2: i = j, the Diagonal elements of the Q^x array #########

    diag_elements = matrix(data = NA, nrow = nhaps, ncol = nsnps-1)
    #Create a for loop, that goes through the HW matrix and gets the minimum of each each succesive column (and across each row)
    for (i in seq(1,nsnps-1) ) { #Loop across the X's
      diag_elements[,i] = apply(HW_Matrix[,i:(i+1)], 1, FUN = min)/HW_Matrix[,i] #Also need to normalize this by the w_i^x
    }

    #Deal with the case when we are dividing by zero (currently this is impossible under the Haplotype Inference framework since we don't have zero weights)
    diag_elements[is.nan(diag_elements)] <- 1

    #Melt this matrix to a vector
    diag_elements = c(diag_elements)

    #Replace the diagonal elements with this diag_elements vector using function above
    Qx_array = `arraydiag`(x = Qx_array ,value = diag_elements)
  }

  #Return the populated Qx array
  return(Qx_array)
}
#' @export
descendant_haplotypes = function(Qx_array,ref_allele_matrix, HW_Matrix, sampled_population_size){
  #Get our dimensionality constants
  nsnps = ncol(HW_Matrix)
  nhaps = nrow(HW_Matrix)
  #Depth of the Qx array
  flow_length = dim(Qx_array)[3]
  #The number of haplotypes that will follow our Qx flow is equivalent to the colSums of HW matrix (in this example)
  number_inferred_haps = sampled_population_size

  #Create a empty matrix that we will populate with the inferred GWAS haplotypes
  GWAS_inferred_haplotypes = matrix(data = NA, nrow = number_inferred_haps, ncol = nsnps)

  #Now we want to get a 'path' through the ref_allele_panel based on the Qx flow matrices we've derived
  path = matrix(data = NA, nrow = number_inferred_haps, ncol = nsnps)

  #Initialize the inferred haplotypes paths based on the weights at SNP 1 (will do this with a while loop for now)
  #We will do this so that the first column is filled until we have no more NA's

  #Counter will tell us which haplotype we are on
  #Normalize each row in the HW matrix
  HW_Matrix_Normalized = sweep(HW_Matrix, 2, colSums(HW_Matrix), FUN="/")
  counter = 1

  while(any(is.na(path[,1])) == TRUE) {
    #Find position of the first NA in the first column (this will tell us where we have filled up to by then)
    NAindex <- which(is.na(path[,1]))
    firstNA <- min(NAindex)

    #Loop over the number of inferred haplotypes
    #Need to account for the case when the path will get filled up, if number of inferred_haplotypes is too small
    if ((firstNA + ceiling(HW_Matrix_Normalized[counter,1]*number_inferred_haps)) > number_inferred_haps) {
      #Fill it up the the rest of the way with the
      path[firstNA:number_inferred_haps,1] = rep(counter,length(fixrstNA:number_inferred_haps))
    }
    else{path[firstNA:(firstNA + ceiling(number_inferred_haps*HW_Matrix_Normalized[counter,1])),1] = rep(counter,ceiling(HW_Matrix_Normalized[counter,1]*number_inferred_haps)+1)
    #Update the counter, and update where we have filled in our path until
    counter = counter + 1}
  }

  #Trace through the rest of the sample inferred haplotype paths, given the Qx flow arrays
  #Loop through all the Qx arrays, which gives us the tracings from position X to position X+1
  for (i in (1:flow_length) ) {
    #j will be going through the "from-haplotypes" flow, ie the rows of the Qx matrices
    for (j in 1:nhaps) {
      #This says how we flow from the jth haplotype to all other haplotypes (k) at position i+1 in the path trace
      haplotype_flow_prob = Qx_array[j,,i]
      #haplotype flow_prob will tell us the probability of going from haplotype j to the other possible k haplotypes with some given prob
      haplotype_from = which(path[,i] == j) #This tells us which haplotypes we would be flowing from
      #Only perform the allocation if the path flows from this haplotype (ie; the flow actually goes to something)
      if (length(haplotype_from) >0 ) {
        for (k in 1:length(haplotype_from)) { #Now we need to go through this vector to actually fill in exactly which haplotype the flow GOES to in each case
          #We need to find where the first NA is, and the start replacing from there, so we don't overwrite any of the path
          NAindex <- which(is.na(path[,i+1]))
          firstNA <- min(NAindex)
          #Stochastically sample through the flow transitions
          set.seed(10)
          path[firstNA,i+1] = sample(1:nhaps, replace = TRUE, size = 1, prob = haplotype_flow_prob) #Fill in the next row with the proper transitions
        }
      }
    }
  }
  #Now we want to take this path we just sampled through and actually return the inferred haplotypes
  #Go through each column in the path matrix and trace out what the haplotype encoding actually is
  for (i in 1:ncol(path)) {
    GWAS_inferred_haplotypes[,i] = ref_allele_matrix[path[,i],i]
  }
  #Return the inferred haplotypes
  return(GWAS_inferred_haplotypes)
}
#' @export
#Function to to calculate LD directly from the haplotype-weight matrix and the Qx's arrays (and associated components)
LD_flow_expectation  = function(HW_Matrix, ref_allele_matrix, Qx_array, recombination){
  #Get the dimensions of the Qx array
  nhaps       = nrow(ref_allele_matrix)
  nsnps       = ncol(ref_allele_matrix)

  weights_sum = colSums(HW_Matrix)
  HW_Matrix = HW_Matrix %*% diag(1/weights_sum)

  #Get a matrix to store the LD_results (this will have dimensions nsnps x nsnps)
  LD_Values = matrix(data = NA, nrow = nsnps, ncol = nsnps)

  allele_frequencies = colSums(ref_allele_matrix * HW_Matrix)
  #Split up the method into when we have recombination and when we don't
  if (recombination == FALSE) {
    #Loop through SNPs (upper diagonal in LD matrix) to get the covariance terms and resulting LD 'r'
    m = as.vector(HW_Matrix[,1]) #Constant across SNPs
    for (i in 1:(nsnps-1)) {
      for (j in i:nsnps) {
        outer = as.vector(ref_allele_matrix[,i]*ref_allele_matrix[,j]) #Look to see when we have 11 encodings
        covar = sum(m*outer)
        f_1_A                  = allele_frequencies[i]
        f_1_B                  = allele_frequencies[j]
        LD_r                   = (covar - f_1_A * f_1_B)/(sqrt(f_1_A*(1-f_1_A)*f_1_B*(1-f_1_B)))
        LD_Values[i,j]         = LD_r
      }
    }
  }

  else{
    #Book-mark which weights on the haplotypes don't change from from to SNP
    identity_index = rep(0,nsnps)
    for (i in 1:(nsnps-1)) {
      if(sum(HW_Matrix[,i]-HW_Matrix[,i+1])==0){ #This line checks if we don't see weight changing
        identity_index[i+1] = 1}
    }
  #With recombination our Qxs will vary along the genome
    #Calculate LD across SNPs
    for (i in 1:(nsnps-1)) { #Loop through upper triangle of this matrix
      Qx_Multiplied = Qx_array[,,i] #Store the first Qx array
      #We will also need to keep track of where along the nsnps we are (using a counter)
      counter = 1
      for (j in i:nsnps) { #Will flip and mirror LD values later
        if (abs(i-j) == 1) { #Adjacent SNP case

          #Formula for covariance
          diag_HW_mult_QX = t( Qx_array[,,i] * diag(HW_Matrix[,i] ))
          f_11_covariance = sum(((diag_HW_mult_QX)) * outer(ref_allele_matrix[,i],ref_allele_matrix[,j]))/weights_sum
          f_1_A                  = allele_frequencies[i]
          f_1_B                  = allele_frequencies[j]
          LD_r                   = (f_11_covariance - f_1_A * f_1_B)/(sqrt(f_1_A*(1-f_1_A)*f_1_B*(1-f_1_B)))
          LD_Values[i,j]         = LD_r
        }
        if (abs(i-j)>1) { #Long Distance Case, this is when will be dealing with Qx matrix multiplication
          if (identity_index[j] == 0) {
            Qx_Multiplied  = Qx_Multiplied %*% Qx_array[,,i + counter] #Store the RECURSIVE multiplication result
          }

          counter = counter + 1 #Add to counter

          #Perform the covariance calculation, this has similar formula to adjacent case
          HW_Subset            = (HW_Matrix[,i])
          weighted_flow_matrix = (Qx_Multiplied * HW_Subset)
          ref_indicator        = ref_allele_matrix[,i]
          x_i_i_plus_one       = crossprod( ref_indicator, weighted_flow_matrix ) #Can this be done quicker?

          #Can perform the final matrix operation as dot product operation since we have a vector now
          f_11_covariance = sum(x_i_i_plus_one*ref_allele_matrix[,j])/weights_sum
          #Calculate LD using covariance and allele frequencies
          f_1_A                  = allele_frequencies[min(i,j)]
          f_1_B                  = allele_frequencies[max(i,j)]
          LD_r                   = (f_11_covariance - f_1_A * f_1_B)/(sqrt(f_1_A*(1-f_1_A)*f_1_B*(1-f_1_B)))
          LD_Values[i,j]         = LD_r
        }
      }
    }
  }
  #Add on the values along the diagonal
  diag(LD_Values) <- 1
  #Flip the symmetric matrix around diagonal to fill in the lower half of the triangle
  LD_Values[lower.tri(LD_Values)] <- t(LD_Values)[lower.tri(LD_Values)]
  print(max(LD_Values))
  return(LD_Values)
}

#Create function that take in Qx flow matrices and uses ref_allele_panel to generate the inferred GWAS sample haplotypes
descendant_haplotypes = function(Qx_array,ref_allele_matrix, HW_Matrix, number_inferred_haps ){
  #Get our dimensionality constants
  nsnps = ncol(HW_Matrix)
  nhaps = nrow(HW_Matrix)
  #Depth of the Qx array
  flow_length = dim(Qx_array)[3]

  #The number of haplotypes that will follow our Qx flow is equivalent to the colSums of HW matrix (in this example)
  number_inferred_haps = number_inferred_haps

  #Create a empty matrix that we will populate with the inferred GWAS haplotypes
  GWAS_inferred_haplotypes = matrix(data = NA, nrow = number_inferred_haps, ncol = nsnps)

  #Now we want to get a 'path' through the ref_allele_panel based on the Qx flow matrices we've derived
  path = matrix(data = NA, nrow = number_inferred_haps, ncol = nsnps)

  #Initialize the inferred haplotypes paths based on the weights at SNP 1 (will do this with a while loop for now)
  #We will do this so that the first column is filled until we have no more NA's

  #Counter will tell us which haplotype we are on
  counter = 1

  while(any(is.na(path[,1])) == TRUE) {
    #Find position of the first NA in the first column (this will tell us where we have filled up to by then)
    NAindex <- which(is.na(path[,1]))
    firstNA <- min(NAindex)
    #Loop over the number of inferred haplotypes

    #Generate a random number to help decide if we floor or ceiling the probability mass * number of inferred haps
    ceiling_floor = runif(1)
    if (ceiling_floor>0.01) {
      #If we do ceiling the mass of haplotypes then we need to deal with situation that we go over
      if ((firstNA + ceiling(number_inferred_haps*HW_Matrix[counter,1])-1)>number_inferred_haps) {
        #Then we just fill in the rest of the path
        path[firstNA:number_inferred_haps,1] = rep(counter,length(path[firstNA:number_inferred_haps,1]))
      }
      else{
        path[firstNA:(firstNA + ceiling(number_inferred_haps*HW_Matrix[counter,1])-1),1] = rep(counter,ceiling(number_inferred_haps*HW_Matrix[counter,1]))
      }
    }
    else{
      path[firstNA:(firstNA + floor(number_inferred_haps*HW_Matrix[counter,1])-1),1] = rep(counter,floor(number_inferred_haps*HW_Matrix[counter,1]))
    }
    #Update the counter, and update where we have filled in our path until
    counter = counter + 1
  }
  #Trace through the rest of the sample inferred haplotype paths, given the Qx flow arrays
  #Loop through all the Qx arrays, which gives us the tracings from position X to position X+1
  for (i in (1:flow_length) ) {
    #j will be going through the "from-haplotypes" flow, ie the rows of the Qx matrices
    for (j in 1:nhaps) {
      #This says how we flow from the jth haplotype to all other haplotypes (k) at position i+1 in the path trace
      haplotype_flow_prob = Qx_array[j,,i]
      #haplotype flow_prob will tell us the probability of going from haplotype j to the other possible k haplotypes with some given prob
      haplotype_from = which(path[,i] == j) #This tells us which haplotypes we would be flowing from
      #Only perform the allocation if the path flows from this haplotype (ie; the flow actually goes to something)
      if (length(haplotype_from) >0 ) {
        for (k in 1:length(haplotype_from)) { #Now we need to go through this vector to actually fill in exactly which haplotype the flow GOES to in each case
          #We need to find where the first NA is, and the start replacing from there, so we don't overwrite any of the path
          NAindex <- which(is.na(path[,i+1]))
          firstNA <- min(NAindex)
          #Stochastically sample through the flow transitions
          set.seed(10)
          path[firstNA,i+1] = sample(1:nhaps, replace = TRUE, size = 1, prob = haplotype_flow_prob) #Fill in the next row with the proper transitions
        }
      }
    }
  }
  #Now we want to take this path we just sampled through and actually return the inferred haplotypes
  #Go through each column in the path matrix and trace out what the haplotype encoding actually is
  for (i in 1:ncol(path)) {
    GWAS_inferred_haplotypes[,i] = ref_allele_matrix[path[,i],i]
  }
  #Return the inferred haplotypes
  return(GWAS_inferred_haplotypes)
}


#This function calculates LD between all SNP's
LD_Matrix = function(haplotypes){

  #Takes in haplotype matrix (dim of haps x snps) to calculate various LD metrics (r here)
  haplotypes = t(haplotypes)
  pAB = haplotypes %*% t( haplotypes ) / ncol( haplotypes)
  pA  = rowMeans( haplotypes )
  pB  = rowMeans( haplotypes )
  D  = pAB - pA %*% t( pB )
  denA = sqrt( 1 / pA / ( 1 - pA ) )
  denB = sqrt( 1 / pB / ( 1 - pB ) )
  r  = t( D * denA ) * denB
  return(r)
}


