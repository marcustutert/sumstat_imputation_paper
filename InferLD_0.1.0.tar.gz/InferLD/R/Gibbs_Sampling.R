library(matrixStats)
#TEST COMMIT
#' @export
gamma_weight_states <- function(weights_resolution,
                               ref_allele_matrix,
                               fst) {

  nhaps <- nrow(ref_allele_matrix)
  gamma_quantiled_weights <- qgamma(p = (1:weights_resolution) / (1 + weights_resolution),
                                   shape = 1 / ( nhaps * ( fst / (1-fst))),
                                   scale = ( nhaps * (fst/(1-fst))))
  gamma_quantiled_weights = gamma_quantiled_weights[is.finite(gamma_quantiled_weights)
                                                    & gamma_quantiled_weights > 0 ]
  return(gamma_quantiled_weights)
}

#' @export
allele_frequency_update = function(ref_allele_matrix,
                                   current_weights,   #Vector of weights
                                   gamma_weight_states,
                                   haplotype_update){

  nsnps   = ncol(ref_allele_matrix)
  nhaps   = nrow(ref_allele_matrix)
  nstates = length(gamma_weight_states)

  x1_sums            = colSums(current_weights*ref_allele_matrix) - (current_weights[haplotype_update] * ref_allele_matrix[haplotype_update,])
  x1_matrix          = matrix(x1_sums, nrow=nstates, ncol=length(x1_sums), byrow=TRUE)
  x2                 = outer(gamma_weight_states, ref_allele_matrix[haplotype_update,], FUN ='*')
  B                  = x1_matrix + x2
  S                  = rep(sum(current_weights)-current_weights[haplotype_update],nsnps)
  A                  = outer(S,gamma_weight_states, FUN='+')
  allele_frequencies = t(B)/A
  #Return the allele frequencies
  return(t(allele_frequencies))
}

incremental_allele_frequency_update = function(ref_allele_matrix,
                                               current_weights,   #Vector of weights
                                               gamma_weight_states,
                                               haplotype_update,
                                               previous_update,
                                               gibbs_matrix){

  nsnps   = ncol(ref_allele_matrix)
  nhaps   = nrow(ref_allele_matrix)
  nstates = length(gamma_weight_states)

  #All that we care about is what
  wt_ref_sums        <<- wt_ref_sums + current_weights[previous_update]*ref_allele_matrix[previous_update,] - current_weights[haplotype_update]*ref_allele_matrix[haplotype_update,]
  #Check if wt_ref_sums is stored globally
  x1_matrix          = matrix(wt_ref_sums, nrow=nstates, ncol=length(wt_ref_sums), byrow=TRUE)
  x2                 = outer(gamma_weight_states, ref_allele_matrix[haplotype_update,], FUN ='*')
  B                  = x1_matrix + x2
  S                  = rep(sum(current_weights)-current_weights[haplotype_update],nsnps)
  A                  = outer(S,gamma_weight_states, FUN='+')
  allele_frequencies = t(B)/A
  #Return the allele frequencies
  return(t(allele_frequencies))
}

#' @export
prob_sigma_given_frequency = function(allele_frequency_matrix,
                                      gwas_variance,
                                      noise,
                                      likelihood_toggle,
                                      case_control_constant = case_control_constant,
                                      j){
  #Turning off Likelihood to test recovery of priors etc
  if (likelihood_toggle == FALSE){
    states = ncol(allele_frequency_matrix)
    snps   = nrow(allele_frequency_matrix)
    prob_normalized = matrix(data = 1/states,nrow = states, ncol = snps)
    return(prob_normalized)
  }

  #Sample weights according to our likelihood function
  if (likelihood_toggle == TRUE){
    het                            = 4 * allele_frequency_matrix *(1-allele_frequency_matrix)
    implied_gwas_variance          = 1/(2*case_control_constant*(allele_frequency_matrix*(1-allele_frequency_matrix)))
    #Divide each row by the observed GWAS variance
    ratio                          = sweep(implied_gwas_variance, MARGIN = 2, STATS = gwas_variance, `/`)
    log_prob_observed              = dgamma(ratio, shape=noise*het, rate=noise*het, log=T)
    log_prob_observed[log_prob_observed < -10]                  = -10
    #Replace log_probabilities that are effectively negative infinity with equal probability
    #log_prob_observed[sapply(log_prob_observed, is.infinite)] <- 0
    probability_across_states = rowSums(log_prob_observed*is.finite(log_prob_observed), na.rm = T) #Deal with the Inf
    return((probability_across_states)) #This is in real probability space
  }
}


#' @export
gibbs_sampler           = function(nSamples,              #Total number of full loops through reference panel
                                   weights_resolution,    #Number of weight states
                                   ref_allele_matrix,     #Reference allele matrix dim:(nhaps,nsnps)
                                   fst,                   #Genetic Drift
                                   gwas_variance,         #Observed GWAS standard errors^2
                                   alpha,                 #Noise term
                                   likelihood_toggle,     #Turn off/on likelihood
                                   debug,                 #If TRUE output the liklihood curve and allele frequencies over time
                                   case_control_constant) #Default set to one (under generative model)
{

  ref_allele_matrix = as.matrix(ref_allele_matrix) #Convert to matrix, just in case

  #Get parameters
  nsnps   = ncol(ref_allele_matrix)
  nhaps   = nrow(ref_allele_matrix)
  nstates = weights_resolution

  #Calculate number of individual updates
  total_updates = nSamples*nhaps

  #There will be a single weight across each of the nhaps, for each individual sample ie: a matrix
  gibbs_matrix = matrix(data = NA, nrow = nhaps,ncol = total_updates + 1)

  #Generate the Gamma Prior under given level of Fst
  gamma_quantiled_weights = gamma_weight_states(weights_resolution = weights_resolution,
                                                ref_allele_matrix  = ref_allele_matrix,
                                                fst                = fst)

  #Uniformly draw weights from the quantiles for each SNP (draw number of weights equal to nhaps)
  initial_weights       = sample(x = gamma_quantiled_weights,size = nhaps, replace = T)
  #initial_weights      = sample(x = gamma_quantiled_weights,size = 1, replace = T)
  #initial_weights      = rep(max(gamma_quantiled_weights),nhaps)
  #Set these initial weights to the start of the gibbs matrix
  gibbs_matrix[,1]    = initial_weights
  #Calculate initial values of AFs and log-likelihoods
  log_likelihood                  =  c()
  inferred_af_given_weights       = matrix(data = NA, nrow = nsnps, ncol = total_updates + 1)
  #Normalise weights
  normalised_weights              = initial_weights/sum(initial_weights)
  #Calculate the allele frequencies
  inferred_af_given_weights[,1]   = colSums(normalised_weights * ref_allele_matrix)
  #Calculate the likelihoods (using noise adjusted likelihood!)
  het                             = 4 * inferred_af_given_weights[,1] *(1-inferred_af_given_weights[,1])
  implied_gwas_variance           = 1/(2*case_control_constant*(inferred_af_given_weights[,1]*(1-inferred_af_given_weights[,1])))
  ratio                           = gwas_variance / implied_gwas_variance
  log_likelihood[1]               = sum(dgamma(ratio, shape=alpha*het, rate=alpha*het, log=T),na.rm = T) #Sum across all variants (log likelihood)
  counter = 1
  #Loop through the next full nSamples through the reference panel
  #Keep the update order the same
  oo           = seq(1:nhaps)
  for (j in 2:(nSamples+1)) {
    #Loop randomly through the haplotypes
    for (idx in 1:nhaps)  {
      flush.console()
      #Keep count of where in the MCMC sampler we are
      cat( sprintf("\r MCM Sampling %f Percentage Done", (counter)/((nSamples)*nhaps)*100))
      #idx                       = oo[idx]
      #Calculate the proposed allele frequencies
      #If counter == 1 then we can not perform the incremental update
      if (counter == 1) {
        proposed_allele_frequency_updates  = allele_frequency_update(ref_allele_matrix              = ref_allele_matrix,
                                                                     current_weights                = gibbs_matrix[,counter],
                                                                     gamma_weight_states            = gamma_quantiled_weights,
                                                                     haplotype_update               = idx)

        #Also store the sum of the weights * ref_allele_matrix minus the current update
        wt_ref_sums <<- colSums(gibbs_matrix[,counter]*ref_allele_matrix) - (gibbs_matrix[idx,counter] * ref_allele_matrix[idx,])
      }
      else{ #Get the previous haplotype_update index
        previous_update = oo[which(oo == idx)-1]
        if (which(oo == idx)-1 == 0) { #Deal with the case when we are on the first index
          previous_update = oo[length(oo)]
          }
        proposed_allele_frequency_updates = incremental_allele_frequency_update(ref_allele_matrix    = ref_allele_matrix,
                                                                                current_weights      = gibbs_matrix[,counter],
                                                                                gamma_weight_states  = gamma_quantiled_weights,
                                                                                haplotype_update     = idx,
                                                                                previous_update      = previous_update,
                                                                                gibbs_matrix         = gibbs_matrix)
      }
      #Calculate probabilites across the states and SNPs
      log_probability_across_states = prob_sigma_given_frequency(allele_frequency_matrix = proposed_allele_frequency_updates,
                                                                   gwas_variance         = gwas_variance,
                                                                   noise                 = alpha,
                                                                   likelihood_toggle     = likelihood_toggle,
                                                                   case_control_constant = case_control_constant)
      #Convert to real space and perform logSumExp trick
      probability_across_states = exp(log_probability_across_states - max(log_probability_across_states))
      #Choose the new state
      new_state = sample(x = seq(1:length(gamma_quantiled_weights)), size = 1,replace = FALSE, prob = probability_across_states)

      gibbs_matrix[,counter+1]    =  gibbs_matrix[,counter]              #Copy over the previous weights
      gibbs_matrix[idx,counter+1] =  gamma_quantiled_weights[new_state]  #Change the weight at the idx we are on

      #Calculate likelihood, if we are debugging
      if (debug == TRUE) {
          #Take the likelihood from the value from log_probability_across_states
          log_likelihood[counter+1]                = log_probability_across_states[new_state]
          #Extract the value from weight_increment of the allele frequencies
          inferred_af_given_weights[,counter+1]  = proposed_allele_frequency_updates[new_state,]
          counter                                = counter + 1 #Update counter
      }
    }
  }
  #Return the matrix for the calculation of the Gibbs implied allele frequencies
  list_results = list(gibbs_matrix,
                      log_likelihood,
                      inferred_af_given_weights)
  #Name the elements in the list
  names(list_results) <- c("Gibbs_Array",
                           "log_likelihood",
                           "inferred_af_given_weights")
  return(list_results)
}
