

library("statmod");

#Checking Fst - Dirichlet - Gamma relationship

#Snp Indexes
xs<-c()
#Number of replicate simulations
n.sim<-1e4

n.ref<-100 #Reference Panel size
fst<-0.05 #Fst level
fq<-0.2   #Frequency of variant
idx<-floor(fq*n.ref) #Indexes

alpha<-1/n.ref*(1-fst)/fst #Set alpha in gamma quantile distr.

for (i in 1:n.sim) { #Loop through all replicates
	y<-rgamma(n.ref, alpha, alpha) #Calculate 100 reference panel weights
	x<-y/sum(y); #Normalized
	xs[i]<-sum(x[1:idx]);
}

hist(xs, xlab="Freq in GWAS");
mean(xs);
var(xs)/(fq*(1-fq));

#All correct!



#Check quantile-based approximation of weight space
alpha<-0.1;
nq<-100;
vv<-qgamma((1:nq)/(nq+1), alpha, alpha);
mean(vv);

#Mean often <1, indicating that noot ideal


#Gaussian quadrature version
ibrary("statmod");
tmp<-gauss.quad.prob(10,dist="gamma",alpha=alpha,beta=1/alpha);
sum(tmp$nodes*tmp$weights);

#This is (always) 1, suggesting that could replace quantile based prior on weights


#Look at distribution of SE values from logistic model

n.gwas<-1e4;
fq<-0.2;
n.sim<-1000;
phi<-0.3;
y<-rbinom(n.gwas, 1, phi);

op<-array(0, c(n.sim, 3));
colnames(op)<-c("FQ", "beta", "se.beta");
for (i in 1:n.sim) {
	fq<-runif(1,0.02, 0.98);
	x<-rbinom(n.gwas, 2, fq);
	y<-sample(y);
	lg<-summary(glm(y~x, family="binomial"));
	op[i,]<-c(mean(x)/2, lg$coef[2,1:2]);
}
e.se<-sqrt(1/(n.gwas*phi*(1-phi))*1/(2*op[,1]*(1-op[,1])));

plot(e.se, op[,3]);
abline(0,1);
rr<-op[,3]^2/e.se^2;
hist(rr);
mean(rr);
sd(rr);
cat("\nImplied shape parameter for Gamma distribution for VAR = ", mean(rr)/var(rr));

plot(op[,1], rr, xlab="Frequency", ylab="Obs Var / Exp Var");

#Suggests that lower-frequency variants have lower shape parameter.

#Obtain implied gamma shape parameter as a function of allele frequency
nq<-10;
qq<-seq(0,1,l=11);
fi<-findInterval(op[,1], qq);
gm.op<-array(0, c(nq, 4));
colnames(gm.op)<-c("Mean.FQ", "Mean.R", "Med.R", "Shape");
for (i in 1:nq) {
	wi<-which(fi==i);
	gm.op[i,]<-c(mean(op[wi,1]), mean(rr[wi]), median(rr[i]), mean(rr[wi])/var(rr[wi]));
}

print(gm.op);

#Look at Heterozygosity versus shape parameter
plot(2*gm.op[,1]*(1-gm.op[,1]), gm.op[,4], xlab="Het", ylab="Shape parameter");
abline(0,1);

#Looks linear - i.e. variance of ratio (inverse of shape parameter) goes with x(1-x)

#Simulate some allele freqs
fq<-runif(100, 0.1, 0.9);

#Shape parameter for simulation of Obs/Exp VAR(BETA) ratio
alpha.ratio.base<-1000;
alpha.var<-alpha.ratio.base*2*fq*(1-fq);
ratio.var<-rgamma(100, shape=alpha.var, rate=alpha.var);

#Calculate density of each simulated ratio
llk.obs<-dgamma(ratio.var, shape=alpha.var, rate=alpha.var, log=T);


