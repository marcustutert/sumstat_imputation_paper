#Consider a gamma distribution with parameters alpha=beta=10;
library("statmod");

alpha<-10;

#No. of quantiles
n.quant<-11;

#Find quantile values
q.vals<-qgamma(p=(1:n.quant)/(n.quant+1), shape=alpha, rate=alpha);

#Use quantiles to estimate mean and variance of distribution
e.mean<-mean(q.vals);
e.var<-mean(q.vals^2)-e.mean^2;

#Here - you see the mean is a decent approximation, but the variance is modest underestimate



#Now consider a gamma distribution with parameters alpha=beta=1;
alpha<-1;

#No. of quantiles
n.quant<-11;

#Find quantile values
q.vals<-qgamma(p=(1:n.quant)/(n.quant+1), shape=alpha, rate=alpha);

#Use quantiles to estimate mean and variance of distribution
e.mean<-mean(q.vals);
e.var<-mean(q.vals^2)-e.mean^2;

#Here - you see the mean is a poorer approximation, and now the variance
#is a substantial underestimate

n<-1000;
fst<-0.02;
c<-fst/(1-fst);
shape<-1/(n*c);
i<-100;
nrep<-10000;
fq.samp<-rep(0, nrep);

for (rep in 1:nrep) {
  wts<-rgamma(n, shape, shape);
  wts<-wts/sum(wts);
  fq.samp[rep]<-sum(wts[1:i]);
}
hist(fq.samp);
mean(fq.samp);
var(fq.samp);
c*i/n*(1-i/n);

#So, even in this case it will be hard to make the quantiles approach well
#(because the shape parameter is very skewed)

n<-1000;
fst<-0.02;
c<-fst/(1-fst);
shape<-1/(n*c);
i<-100;
nrep<-10000;
fq.samp<-rep(0, nrep);
nq<-9;
q.vals<-qgamma((1:nq)/(nq+1), shape, shape);

for (rep in 1:nrep) {
  wts<-sample(q.vals, n, rep=T);  #Using the quantile approach with uniform sampling
  wts<-wts/sum(wts);
  fq.samp[rep]<-sum(wts[1:i]);
}
hist(fq.samp);
mean(fq.samp);
var(fq.samp);
c*i/n*(1-i/n);

#You'll see the variance in AF is a substantial underestimate of what it should be.


#However doing this wtih Gaussian Quadrature now works!
n<-1000;
fst<-0.02;
c<-fst/(1-fst);
shape<-1/(n*c);
i<-100;
nrep<-10000;
fq.samp<-rep(0, nrep);
nq<-9;
q.vals<-gauss.quad.prob(nq, dist="gamma", alpha=shape, beta=1/shape);

for (rep in 1:nrep) {
  wts<-sample(q.vals$nodes, n, p=q.vals$weights, rep=T);
  wts<-wts/sum(wts);
  fq.samp[rep]<-sum(wts[1:i]);
}
hist(fq.samp);
mean(fq.samp);
var(fq.samp);
c*i/n*(1-i/n);




