#Code to test 1000G Simulation using Viterbi Algorithim (Base Case)

