#Playing around with the scratch code for the marginal posteriors
library( data.table )
library( plotly )

pi_ref    = 0.3
Fst       = 1e-3
pi_pop_zn = seq( 0.15, pi_ref , 0.02)
ratio     = seq( 0, 5, 0.1 )

###################################################################/
# Name: posterior_calc
###################################################################/
posterior_calc = function(
  pi_ref,
  pi_pop_zero_noise,
  Fst,
  alpha,
  pi_pop_x
)
{
  # prior distributed beta( pi_ref * c, ( 1-pi_ref) * c )
  c     = (1 / Fst - 1)
  prior = (c * pi_ref -1 ) * log( pi_pop_x ) + ( c * ( 1 - pi_ref ) -1 ) * log( 1 - pi_pop_x )

  # probability of the observed sigma_b / sigma_b_from_pi_pop is gamma distributed
  observed_sigma_b = 1 / pi_pop_zero_noise / ( 1 - pi_pop_zero_noise )
  implied_sigma_b  = 1 / pi_pop_x / ( 1 - pi_pop_x )
  ratio            =  observed_sigma_b / implied_sigma_b
  prob_observed    = ( alpha - 1 ) * log( ratio ) - alpha * ratio

  # take the product of the prob_observed and the prior (we're in log space)
  posterior  = prior + prob_observed

  # normalize and exponentiate
  posterior  = posterior - max( posterior )
  posterior  = exp( posterior)
  posterior  = posterior / sum( posterior )
  return( posterior )
}

###################################################################/
# Name: mean_posterior
###################################################################/
mean_posterior = function(
  pi_ref,
  pi_pop_zero_noise,
  Fst,
  alpha,
  n = 1e4
)
{
  pi_pop_x  = seq(1/n, 1 - 1/n, 1/n)
  posterior = posterior_calc( Fst = Fst, pi_ref = pi_ref, pi_pop_zero_noise = pi_pop_zero_noise, alpha = alpha, pi_pop_x = pi_pop_x )
  return( sum( pi_pop_x * posterior ) )
}

#Loop over the ratio's and the pi_pop_zn and store them in the matrix we defined above...
results = matrix( data = NA, nrow = length( ratio ), ncol = length( pi_pop_zn ) )
for( i in seq( ratio ) )
  for( j in seq( pi_pop_zn ) )
    results[ i, j ] = mean_posterior( pi_ref, pi_pop_zn[ j ], Fst, ratio[ i ] / Fst )

# convert in to something easier to deal with
results = as.data.table( results )
setnames( results, as.character( pi_pop_zn ) )
results[ , ratio := ratio ]
results = melt.data.table( results, "ratio", variable.name = "pi_pop_zn", value.name = "mean_pi_pop" )
results[ , pi_pop_zn_num := as.numeric( as.vector( pi_pop_zn) )]
results[ , diff := ( mean_pi_pop -  pi_pop_zn_num ) / ( pi_ref - pi_pop_zn_num )]
results[ , approx := 1 / ( 1 + ratio * (1-2*pi_pop_zn_num )^2/pi_pop_zn_num/(1-pi_pop_zn_num) )]
results[ , ratio_scaled := ratio *  (1-2*pi_pop_zn_num )^2/pi_pop_zn_num/(1-pi_pop_zn_num) ]

p = plot_ly( results, x = ~ratio_scaled, y = ~diff, color = ~pi_pop_zn, type = "scatter", mode = "markers" ) %>%
  add_lines(y = ~approx, name = "Gaussian Approximation", color = NULL)
show( p )
p = plot_ly( results, x = ~ratio, y = ~diff, color = ~pi_pop_zn, type = "scatter", mode = "markers" ) %>%
  add_lines(y = ~approx, name = "Gaussian Approximation")
show( p )
