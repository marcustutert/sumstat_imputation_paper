###Create Toy Data###########

#Generate Haplotype Weight Matrix where weights do not vary along columns
HW_Matrix = cbind(c(4,1,2),c(4,1,2),c(4,1,2),c(4,1,2))
#Normalize the matrix
sums = colSums(HW_Matrix)
HW_Matrix_Norm = HW_Matrix %*% diag(1/sums)

#Create a Reference Haplotype Panel (dimension: nhaps x nsnps)
nsnps = ncol(HW_Matrix)
nhaps = nrow(HW_Matrix)
#Fill in toy encodings
ref_allele_matrix =  cbind(c(0,1,0),c(1,0,0),c(0,0,1),c(1,0,0))
########################

#This function only works on integer weights (NON normalized)
LD_calculate_integers = function(ref_allele_matrix,HW_Matrix){
  nsnps = ncol(HW_Matrix)
  nhaps = nrow(HW_Matrix)
  weighted_haplotypes = ref_allele_matrix[rep(1:nrow(ref_allele_matrix), times = HW_Matrix[,1]), ]
  weighted_haplotypes = t(weighted_haplotypes)
  pAB = weighted_haplotypes %*% t( weighted_haplotypes ) / ncol( weighted_haplotypes)
  pA  = rowMeans( weighted_haplotypes )
  pB  = rowMeans( weighted_haplotypes )
  D  = pAB - pA %*% t( pB )
  denA = sqrt( 1 / pA / ( 1 - pA ) )
  denB = sqrt( 1 / pB / ( 1 - pB ) )
  r  = t( D * denA ) * denB
  return(r)
}

#Test if it works:
LD_calculate_integers(ref_allele_matrix =ref_allele_matrix, HW_Matrix = HW_Matrix) #Works and is fast

#Now try to implement the way to do this with  rational weights
#Goal here Robbie is to remove the double for loop!
LD_calculate_rational = function(ref_allele_matrix =ref_allele_matrix, HW_Matrix = HW_Matrix){

  LD_Values = matrix(data = NA, nrow = nsnps, ncol = nsnps) #Initialize empty LD matrix
  nhaps       = nrow(ref_allele_matrix)
  nsnps       = ncol(ref_allele_matrix)

  #Prestore allele frequencies using formula given in methods doc
  allele_frequencies = colSums(ref_allele_matrix*HW_Matrix)

  #Loop through SNPs (upper diagonal in LD matrix) to get the covariance terms and resulting LD 'r'
  m = as.vector(HW_Matrix[,1]) #Constant across SNPs
  for (i in 1:(nsnps-1)) {
    for (j in i:nsnps) {
      outer = as.vector(ref_allele_matrix[,i]*ref_allele_matrix[,j]) #Look to see when we have 11 encodings
      covar = sum(m*outer)
      f_1_A                  = allele_frequencies[i]
      f_1_B                  = allele_frequencies[j]
      LD_r                   = (covar - f_1_A * f_1_B)/(sqrt(f_1_A*(1-f_1_A)*f_1_B*(1-f_1_B)))
      LD_Values[i,j]         = LD_r
    }
  }
  #Add on the values along the diagonal
  diag(LD_Values) <- 1
  #Flip the symmetric matrix around diagonal to fill in the lower half of the triangle
  LD_Values[lower.tri(LD_Values)] <- t(LD_Values)[lower.tri(LD_Values)]
  return(LD_Values)
}

LD_calculate_rational(ref_allele_matrix = ref_allele_matrix, HW_Matrix = HW_Matrix_Norm)
#Same answer as above just SLOW
