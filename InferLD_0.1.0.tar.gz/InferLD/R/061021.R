# #Testing the windowing and processing of the InferLD data
# #Test case for Robbie re: sumstat imputation
# genotyped_sumstats = fread("genotyped_sumstats_munged", header = T) #File with the genotyped summary statistics
# genotyped_sumstats = genotyped_sumstats[order(BP),]
# reference_panel    = t(fread("reference_panel.haps", header = F))    #Reference panel
# legend             = fread("reference_panel.legend", header = T)    #Legend file for the reference 
# true_data          = fread("/well/mcvean/mtutert/sumstat_imputation_paper/sumstat_imputation_paper/hapgen2_sim_data/full_sumstats_munged.sumstats")
# 
# 
# #Get the index of the imputed SNPs
# imputed_SNPs_index = (which(!legend$id %in%  genotyped_sumstats$SNP))
# #Get the index of the typed SNPs
# typed_SNPs_index   = (setdiff(1:ncol(reference_panel),imputed_SNPs_index))
# #Get the LD
# LD = LD_Matrix(haplotypes = reference_panel)
# #Perform the sumstat imputation
# imputed_zs                   = sumstat_impute(typed_snps         = typed_SNPs_index,
#                                               untyped_snps_index = imputed_SNPs_index,
#                                               typed_z_scores     = genotyped_sumstats$Z,
#                                               LD                 = LD)
# 
# #Compare with the true data
# true_data    = fread("/well/mcvean/mtutert/sumstat_imputation_paper/sumstat_imputation_paper/hapgen2_sim_data/full_sumstats_munged.sumstats")
# imputed_data = cbind(legend[imputed_SNPs_index]$id,imputed_zs)
# colnames(imputed_data) = c("SNP","Z")
# compare = merge(true_data,imputed_data,by = "SNP")
# summary(lm(compare$Z.y~compare$Z.x))$r.squared
# plot(compare$Z.y,compare$Z.x)
