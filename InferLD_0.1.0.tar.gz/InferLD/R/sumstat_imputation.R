#Functions to Preprocess/Postprocess data to perform and then perform sumstat imputation

# To run InferLD will need to provide a file of summary statistics (in mungeable format to ensure no missingness) and a reference panel (using IMPUTE2 format)
# The IMPUTE2 format will be a list of haplotypes and an associated legend file
# Assume that the reference and the sumstats will be SNPs on the same chromosome (change later!)

sumstat_imputation = function(window_size     = 1e6,  #Copying IMPG
                              buffer          = 2500, #Copying IMPG
                              munged_sumstats,        #Path to the munged_sumstats relative to Data_InferLD
                              reference_panel,        #Path to the reference panel relative to Data_InferLD (HAPS format); nhaps x nsnps
                              legend_file){           #Path to the legend file relative to Data_InferLD (Legend format)

#Load in the three files we need to process this data
reference_panel             = t(fread(reference_panel, header = F)) #Haplotype format (no headers though!)
legend                      = fread(legend_file, header = T)        #Legend file (see IMPUTE2)
genotyped_sumstats          = fread(munged_sumstats, header = T)    #Munged sumstats

#Next, we need to throw out anything in the reference panel that is at 0% MAF
print(sprintf("Number of SNPs in Reference Panel before filtering is %s", ncol(reference_panel)))
print(sprintf("Number of SNPs in Genotyped Sumstats before filtering is %s", nrow(genotyped_sumstats)))
non_segregating_snps = which(colMeans(reference_panel) == 0 | colMeans(reference_panel) == 1 ) #Find all non-segregating SNPs in the reference panel
print(sprintf("Number of SNPs in Reference Panel at 0 Percent MAF is %s", length(non_segregating_snps)))
print("Begin Filtering!")

#Remove non-segregating SNPs (if they are any!)
if (length(non_segregating_snps) > 0) {
  legend               = legend[-non_segregating_snps,]
  #Remove from reference panel
  reference_panel      = reference_panel[,-non_segregating_snps]
}

print(sprintf("After filtering for non-segregating SNPs, the number of SNPs in Reference Panel is %s", ncol(reference_panel)))

#Remove SNPs in the genotyped sumstats that are not in the reference panel
snps_in_genotyped_sumstats_not_in_reference_panel = which(!genotyped_sumstats$SNP %in% legend$id)

if (length(snps_in_genotyped_sumstats_not_in_reference_panel) > 0 ) {
  genotyped_sumstats = genotyped_sumstats[-which(!genotyped_sumstats$SNP %in% legend$id),]
}
print(sprintf("After filtering for SNPs present in sumstats and not Reference, the number of SNPs in sumstats is %s", nrow(genotyped_sumstats)))

#Double check we did the matching correct!
if (length(setdiff(genotyped_sumstats$SNP, legend$id)) == 0) {
  print("Filtering and matching was (probably) done correctly")
}

else{
  print("Double check filtering SNPs, some SNPs are present in sumstats but not in the reference")
}

#Get a list of the SNPs we wish to impute
snps_to_be_imputed = nrow(legend) - nrow(genotyped_sumstats)
print(nrow(genotyped_sumstats))
print(sprintf("There are %s SNPs that will be imputed in this region", snps_to_be_imputed))

write.table(genotyped_sumstats, "genotyped_sumstats_Robbie", quote = F, row.names = F, col.names = T)
write.table(reference_panel, "reference_panel_Robbie", quote = F, row.names = F, col.names = F)
write.table(legend_file, "legend_Robbie", quote = F, col.names = T, row.names = F)


#Get the index of the typed SNPs
imputed_SNPs_index = sort(which(!legend$id %in%  genotyped_sumstats$SNP))
#Get the index of the imputed SNPs
typed_SNPs_index   = sort(setdiff(1:ncol(reference_panel),imputed_SNPs_index))
#Get the LD
browser()
LD = LD_Matrix(haplotypes = reference_panel)
#Perform the sumstat imputation
imputed_zs_ref_LD            = sumstat_impute(typed_snps         = typed_SNPs_index,
                                              untyped_snps_index = imputed_SNPs_index,
                                              typed_z_scores     = genotyped_sumstats$Z,
                                              LD                 = LD)
hist(imputed_zs_ref_LD)
write.table("imputed_InferLD", x = cbind(legend$id[imputed_SNPs_index],imputed_zs_ref_LD), quote = F, col.names = F, row.names = F)
}

sumstat_impute = function(typed_snps,
                          untyped_snps_index,
                          typed_z_scores,
                          LD)
{
  LD_typed_untyped   = LD[typed_snps,untyped_snps_index] #LD of typed - untyped pairs
  inv_LD_typed       = solve(LD[typed_snps,typed_snps] + 0.1*diag(length(typed_snps)))#inverse of LD of typed SNPs
  W                  = LD[untyped_snps_index, typed_snps] %*% inv_LD_typed #these are the weights that turn typed to imputed
  infos              = as.numeric(rowSums(W * LD[untyped_snps_index,typed_snps])) #info measures per each untyped
  z.imp              = (W %*% (typed_z_scores))/sqrt(infos) #use scaling 1/sqrt(infos) to get var=1 for z-scores
  return((z.imp))
}


#This function calculates LD between all SNP's
LD_Matrix = function(haplotypes){

  #Takes in haplotype matrix (dim of haps x snps) to calculate various LD metrics (r here)
  haplotypes = t(haplotypes)
  pAB = haplotypes %*% t( haplotypes ) / ncol( haplotypes)
  pA  = rowMeans( haplotypes )
  pB  = rowMeans( haplotypes )
  D  = pAB - pA %*% t( pB )
  denA = sqrt( 1 / pA / ( 1 - pA ) )
  denB = sqrt( 1 / pB / ( 1 - pB ) )
  r  = t( D * denA ) * denB
  return(r)
}

