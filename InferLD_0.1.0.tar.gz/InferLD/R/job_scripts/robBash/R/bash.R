bash_error_code        = "BASH_ERROR::"
default_external_dir   = "jobs/Scratch"
default_external_host  = "tutert@rescomp2.well.ox.ac.uk"
default_clusterQueue   = "short.qc"
default_clusterProject = "mcvean.prjc"
containerSeperator     = "\t"
default_hold_jobID     = "" #Empty string for holdjobID

##################################################################/
# bash.job.class ####
# object to hold information about a job
##################################################################/
bash.job.class = utils.class(
  "bash.job.class",
  private = list(
    .jobName        = "",
    .jobFullName    = "",
    .jobDate        = "",
    .jobTime        = "",
    .jobNumber      = NULL,
    .script         = "",
    .scriptFile     = "",
    .dirJob         = "",
    .dirLocal       = "",
    .clusterQueue   = "",
    .clusterProject = "",
    .externalHost   = "",
    .cores          = 1,
    .arrayJobs      = 1,
    .submitted      = FALSE,
    .outputFiles    = c(),
    .hold_jobID     = "",
    ##################################################################/
    # .privateMembers
    ##################################################################/
    .privateMembers = function()
    {
      all = ls( private, all.names = TRUE )
      for( idx in length( all ):1 )
        if( is.function( private[[ all[ idx ] ]] ) )
          all = all[ -idx ]
      return( all )
    },
    ##################################################################/
    # .integerMembers
    ##################################################################/
    .integerMembers = function()
    {
      return( c( ".jobNumber", ".arrayJobs", ".cores" ) )
    },
    ##################################################################/
    # .jobObjectFile
    ##################################################################/
    .jobObjectFile = function()
    {
      return( sprintf( sprintf( "%s.jobObject", self$jobFullName ) ) )
    },
    ##################################################################/
    # .writeJobObject
    ##################################################################/
    .writeJobObject = function()
    {
      # get all private variables
      names  = private$.privateMembers()
      values = c()
      for( idx in 1:length( names ) )
        if( !is.null( private[[ names[ idx ] ]] ))
        values[ idx ] = private[[ names[ idx ] ]]
      dt = data.table( names = names, values = values )

      # write the private members to file
      file = private$.jobObjectFile()
      fwrite( dt, file = sprintf( "%s/%s", self$dirLocal, file ), sep = containerSeperator )
      bash.uploadFiles( file, dirLocal = self$dirLocal, dirExternal = self$dirJob, externalHost = self$externalHost )
    }
  ),
  public = list(
    ###################################################################################/
    # intialize
    ###################################################################################/
    initialize = function(
      jobName        = "",
      script         = "",
      dirLocal       = tempdir(),
      clusterQueue   = default_clusterQueue,
      clusterProject = default_clusterProject,
      externalHost   = default_external_host,
      dirJob         = default_external_dir,
      cores          = 1,
      arrayJobs      = 1,
      hold_jobID     = default_hold_jobID,
      jobObject      = NULL
    )
    {
      if( !is.null( jobObject ) & is.data.table( jobObject ) )
      {
        integerMembers = private$.integerMembers()
        for( idx in 1:jobObject[ ,.N ] )
          if( jobObject[ idx, names ] %in% integerMembers )
            private[[ jobObject[ idx, names ] ]] = as.integer( jobObject[ idx, values ] )
          else
            private[[ jobObject[ idx, names ] ]] = jobObject[ idx, values ]

          # check to see if the local directory still exists, if not then change it
          savedDirLocal = self$dirLocal
          if( !dir.exists( savedDirLocal ) )
            private$.dirLocal = dirLocal

        return()
      }

      if( jobName == "" )
        utils.throw( "must specify job name")
      if( script == "" )
        utils.throw( "must specify job script")

      private$.jobName        = str_replace_all( jobName, " ", "_")
      private$.dirJob         = dirJob
      private$.clusterQueue   = clusterQueue
      private$.clusterProject = clusterProject
      private$.externalHost   = externalHost
      private$.cores          = cores
      private$.arrayJobs      = arrayJobs
      private$.hold_jobID     =  hold_jobID

      # get run date and attach time and unique name to the job
      time                 = Sys.time()
      private$.jobDate     = format( time, "%Y%m%d")
      private$.jobTime     = format( time, "%H:%M:%S" )
      private$.jobFullName = sprintf( "%s_%s_%s_%s", private$.jobName, private$.jobDate, format( time, "%H%M%S" ), substr( UUIDgenerate(), 1, 3 ) )
      private$.dirLocal    = dirLocal
      self$updateScript( script )
    },
    ###################################################################################/
    # updateScript
    ###################################################################################/
    updateScript = function( script )
    {
      if( self$submitted == TRUE )
        utils.throw( "Cannot update script on a submitted jobs ")
      # check to see what type of script has been submitted

      dirLocal = private$.dirLocal
      if( file.exists( script ) )
      {
        # if the file exists then we use it set the local directory to the directory it is in
        private$.scriptFile = basename( script )
        private$.script     = paste( readLines( file( script ) ), collapse = "\n" )
        dirLocal            = substr( script, 1, str_length( script ) - str_length( basename( script ) ) )
      } else
        if( file.exists( sprintf( "%s/%s", private$.dirLocal, script ) ) )
        {
          private$.scriptFile = script
          private$.script     = paste( readLines( file( sprintf( "%s/%s", private$.dirLocal, script ) ) ), collapse = "\n" )
        } else
        {
          private$.script     = script
          private$.scriptFile = sprintf( "%s.sh", private$.jobFullName )
          fileConn = file( sprintf( "%s/%s", private$.dirLocal, private$.scriptFile  ) )
          writeLines( script, fileConn )
          close( fileConn )
        }
      private$.dirLocal = dirLocal
    },
    ###################################################################################/
    # jobStatus
    ###################################################################################/
    jobStatus = function()
    {
      if( is.null( self$jobNumber ) )
        return( "job not submitted" )

      status = bash.execute.commands( sprintf( "qstat -j %s", self$jobNumber ), externalHost = self$externalHost )
      return( status )
    },
    ###################################################################################/
    # log
    ###################################################################################/
    log = function()
    {
      logFileFull = sprintf( "%s/%s*", self$dirLog, self$logFile )
      return( bash.execute.commands( sprintf( "cat %s", logFileFull ), externalHost = self$externalHost ) )
    },
    ###################################################################################/
    # error
    ###################################################################################/
    error = function()
    {
      errorFileFull = sprintf( "%s/%s*", self$dirError, self$errorFile )
      return( bash.execute.commands( sprintf( "cat %s", errorFileFull ), externalHost = self$externalHost ) )
    },
    ###################################################################################/
    # RData
    ###################################################################################/
    RData = function( reload = FALSE, download = TRUE )
    {
      # find the names of files to expect
      outputFiles = self$outputFiles
      RDataFiles  = outputFiles[ which( str_ends( outputFiles, ".RData" ) ) ]
      if( !length( RDataFiles ) )
        return( "Jobs does not produce any RData files")

      # see which if any have been downloaded already
      localFiles    = system( sprintf( "ls %s/%s", self$dirLocal, RDataFiles ), intern = TRUE  )
      externalFiles = bash.execute.commands( sprintf( "ls %s/%s", self$dirJob, RDataFiles ), externalHost = self$externalHost )
      allExtFiles   = sprintf( "%s/%s", self$dirJob, RDataFiles )

      # if reload = FALSE then only download files we don't know about
      if( reload == FALSE )
        externalFiles = setdiff( externalFiles, localFiles )

      # deal with * pattern, far more efficient to download them in one go
      fileBits = stri_split_fixed( allExtFiles, "*", simplify = TRUE )
      if( ncol( fileBits ) == 2 )
      {
        starFiles = allExtFiles[ fileBits[ , 2 ] != "" ]
        fileBits  = fileBits[ fileBits[ , 2 ] != "",  , drop = FALSE ]
        for( idx in 1:nrow( fileBits ) )
        {
          extStarFiles  = substr( externalFiles, 1, nchar( fileBits[ idx, 1 ] ) )  == fileBits[ idx, 1 ]
          extStarFiles  = extStarFiles * ( substr( externalFiles, nchar( externalFiles ) - nchar( fileBits[ idx, 2 ] ) + 1 , nchar( externalFiles) )  == fileBits[ idx, 2 ] )
          externalFiles = c( starFiles, externalFiles[ !extStarFiles ] )
        }
      }

      # now download if necesarry
      if( length( externalFiles ) & download == TRUE )
      {
        externalFiles = str_replace( externalFiles, self$dirJob, "" )
        bash.downloadFiles( externalFiles, dirExternal = self$dirJob, dirLocal = self$dirLocal, externalHost = self$externalHost )
      }

      # after downloading files see which ones now exist
      downloadedFiles = system( sprintf( "ls %s/%s", self$dirLocal, RDataFiles ), intern = TRUE )

      # finally read in the local files and return the results
      results = list()

      if( length( downloadedFiles ) )
      {
        for( file in downloadedFiles )
          results[[ basename( file ) ]] = readRDS( file )
      }

      return( results)
    },
    ##################################################################/
    # submit
    ##################################################################/
    submit = function()
    {
      # upload the file shell script to be run
      bash.uploadFiles( self$scriptFile, dirLocal = self$dirLocal, dirExternal = self$dirJob )
      commands = c(
        paste(
          sprintf( "qsub -N %s", self$jobFullName ),
          "-cwd -V",
          sprintf( "-q %s", self$clusterQueue ),
          sprintf( "-P %s", self$clusterProject),
          ifelse( self$arrayJobs > 1, sprintf( "-t 1-%d:1", self$arrayJobs ) , ""),
          sprintf( "-o %s", self$dirLog ),
          sprintf( "-e %s", self$dirError),
          sprintf( "-pe shmem %d", self$cores ),
          sprintf("-hold_jid %s", self$hold_jobID),
          sprintf( "%s/%s", self$dirJob, self$scriptFile )
        )
      )
      print(commands)
      res = bash.execute.commands( commands, externalHost = self$externalHost )
      # parse the command return to get the job number
      bits = str_split_fixed( res, " ", 4 )
      if( bits[ 1 ] == "Your" & bits[ 2 ] == "job" &!is.na( as.integer( bits[ 3 ] ) ) )
        private$.jobNumber = as.integer( bits[ 3 ] )
      else
      {
        if( bits[ 1 ] == "Your" & bits[ 2 ] == "job-array" &!is.na( as.integer( stri_split_fixed( bits[3], ".", simplify = TRUE)[1,1] ) ) )
          private$.jobNumber = as.integer( stri_split_fixed( bits[3], ".", simplify = TRUE)[1,1] )
        else
          utils.throw( sprintf( "Job was failed to be submitted:\n\n %s", res ) )
      }


      # finally write the job object container with all the meta-data so can be reloaded
      private$.submitted = TRUE
      private$.writeJobObject()

      return( self$jobNumber  )
    }
  ),
  active = list(
    ###################################################################################/
    # jobName
    ###################################################################################/
    jobName = function ( jobName )
    {
      if( missing( jobName ) )
        return( private$.jobName )
      else
        utils.throw( "Cannot change jobName once intitialized" )
    },
    ###################################################################################/
    # dirJob
    ###################################################################################/
    dirJob = function ( dirJob )
    {
      if( missing( dirJob ) )
        return( private$.dirJob )
      else
        utils.throw( "Cannot change dirJob once intitialized" )
    },
    ###################################################################################/
    # jobDate
    ###################################################################################/
    jobDate = function ( jobDate )
    {
      if( missing( jobDate ) )
        return( private$.jobDate )
      else
        utils.throw( "Cannot change jobDate once intitialized" )
    },
    ###################################################################################/
    # jobTime
    ###################################################################################/
    jobTime = function ( jobTime )
    {
      if( missing( jobTime ) )
        return( private$.jobTime )
      else
        utils.throw( "Cannot change jobTime once intitialized" )
    },
    ###################################################################################/
    # script
    ###################################################################################/
    script = function ( script )
    {
      if( missing( script ) )
        return( private$.script )
      else
        utils.throw( "Cannot change script once intitialized" )
    },
    ###################################################################################/
    # script.print
    ###################################################################################/
    script.print = function ( script )
    {
      if( missing( script ) )
      {
        cat( self$script,"\n\n" )
        return()
      }
      else
        utils.throw( "Cannot change script once intitialized" )
    },
    ###################################################################################/
    # scriptFile
    ###################################################################################/
    scriptFile = function ( scriptFile )
    {
      if( missing( scriptFile ) )
        return( private$.scriptFile )
      else
        utils.throw( "Cannot change scriptFile once intitialized" )
    },
    ###################################################################################/
    # jobFullName
    ###################################################################################/
    jobFullName = function ( jobFullName )
    {
      if( missing( jobFullName ) )
        return( private$.jobFullName )
      else
        utils.throw( "Cannot change jobFullName once intitialized" )
    },
    ###################################################################################/
    # jobNumber
    ###################################################################################/
    jobNumber = function ( jobNumber )
    {
      if( missing( jobNumber ) )
        return( private$.jobNumber )
      else
        utils.throw( "Cannot change jobNumber once intitialized" )
    },
    ###################################################################################/
    # dirLog
    ###################################################################################/
    dirLog = function ( dirLog )
    {
      if( missing( dirLog ) )
        return( private$.dirJob )
      else
        utils.throw( "Cannot change dirLog" )
    },
    ###################################################################################/
    # dirError
    ###################################################################################/
    dirError = function ( dirError )
    {
      if( missing( dirError ) )
        return( private$.dirJob )
      else
        utils.throw( "Cannot change dirError" )
    },
    ###################################################################################/
    # dirLocal
    ###################################################################################/
    dirLocal = function ( dirLocal )
    {
      if( missing( dirLocal ) )
        return( private$.dirLocal )
      else
        utils.throw( "Cannot change dirLocal" )
    },
    ###################################################################################/
    # clusterQueue
    ###################################################################################/
    clusterQueue = function ( clusterQueue )
    {
      if( missing( clusterQueue ) )
        return( private$.clusterQueue )
      else
        utils.throw( "Cannot change clusterQueue" )
    },
    ###################################################################################/
    # clusterProject
    ###################################################################################/
    clusterProject = function ( clusterProject )
    {
      if( missing( clusterProject ) )
        return( private$.clusterProject )
      else
        utils.throw( "Cannot change clusterProject" )
    },
    ###################################################################################/
    # externalHost
    ###################################################################################/
    externalHost = function ( externalHost )
    {
      if( missing( externalHost ) )
        return( private$.externalHost )
      else
        utils.throw( "Cannot change externalHost" )
    },
    ###################################################################################/
    # cores
    ###################################################################################/
    cores = function( cores )
    {
      if( missing( cores ) )
        return( private$.cores )
      else
        utils.throw( "Cannot change cores" )
    },
    ###################################################################################/
    # arrayJobs
    ###################################################################################/
    arrayJobs = function( arrayJobs )
    {
      if( missing( arrayJobs ) )
        return( private$.arrayJobs )
      else
        utils.throw( "Cannot change arrayJobs" )
    },
    ###################################################################################/
    # logFile
    ###################################################################################/
    logFile = function( logFile )
    {
      if( missing( logFile ) )
        return( sprintf( "%s.o%d", self$jobFullName, self$jobNumber ) )
      else
        utils.throw( "Cannot set logFile" )
    },
    ###################################################################################/
    # errorFile
    ###################################################################################/
    errorFile = function( errorFile )
    {
      if( missing( errorFile ) )
        return( sprintf( "%s.e%d", self$jobFullName, self$jobNumber ) )
      else
        utils.throw( "Cannot set errorFile" )
    },
    ###################################################################################/
    # outputFiles
    ###################################################################################/
    outputFiles = function( outputFiles )
    {
      if( missing( outputFiles ) )
        return( private$.outputFiles )
      else
        private$.outputFiles = outputFiles
    },
    ###################################################################################/
    # submitted
    ###################################################################################/
    submitted = function( submitted )
    {
      if( missing( submitted ) )
        return( private$.submitted )
      else
        utils.throw( "Cannot set submitted" )
    },
    ###################################################################################/
    # hold_jobID
    ###################################################################################/
    hold_jobID = function ( hold_jobID )
    {
      if( missing( hold_jobID ) )
        return( private$.hold_jobID )
      else
        utils.throw( "Cannot change holdJobID once intitialized" )
    }
  )
)


##################################################################/
# bash.addCommand ####
# helper function for building commands
##################################################################/
bash.addCommand = function( commands = NULL, command )
{
  if( is.null( commands ) )
    commands = c( command )
  else
    commands = c( commands, command )
  return( commands )
}

##################################################################/
# bash.cd ####
# change directory and error if fails
##################################################################/
bash.cd = function( commands = NULL, dir )
{
  if( !is.null( commands ) )
    idx = length( commands ) + 1
  else
    idx = 1;
  command = sprintf( "if [ -d %s ]; then cd %s; else echo '%s[line %d] no directory %s'; exit; fi", dir, dir, bash_error_code, idx, dir )
  return( bash.addCommand( commands, command ) )
}

##################################################################/
# bash.mkdir ####
# change directory and error if fails
##################################################################/
bash.mkdir = function( commands = NULL, dir )
{
  if( !is.null( commands ) )
    idx = length( commands ) + 1
  else
    idx = 1;
  command = sprintf( "if [ ! -d %s ]; then mkdir %s; echo 'mkdir %s'; fi", dir, dir, dir )
  return( bash.addCommand( commands, command ) )
}

##################################################################/
# bash.ls ####
# change directory and error if fails
##################################################################/
bash.ls = function( commands = NULL )
{
  return( bash.addCommand( commands, "ls" ) )
}

##################################################################/
# bash.rm ####
# remove files
##################################################################/
bash.rm = function( commands = NULL, files, dir = NULL )
{
  if( !is.null( dir ) )
    files = sprintf( "%s/%s", dir, files )
  if( length( files ) > 1 )
    files = paste( files, sep = " " )

  return( bash.addCommand( commands, sprintf( "rm %s", files ) ) )
}

##################################################################/
# bash.rmdir ####
# remove files
##################################################################/
bash.rmdir = function( commands = NULL,  dir = NULL )
{
  return( bash.addCommand( commands, sprintf( "rmdir %s", dir ) ) )
}

##################################################################/
# bash.execute.commands ####
# runs commands on external host
##################################################################/
bash.execute.commands = function( commands, externalHost = default_external_host, local = FALSE )
{
  if( local == TRUE )
  {
    result = list();
    for( idx in 1:length( commands ) )
      result[[ idx ]] = system( commands[ idx ], intern = TRUE )
    return( result )
  }

  command = paste( commands[ commands != "" ], collapse = "; " )
  result  = system( sprintf( "sshpass -f /Users/marcustutert/mpass.txt ssh %s \"%s\"", externalHost, command ), intern = TRUE )

  lines = length( result )
  if( lines > 0 && substr( result[ lines ], 1, str_length( bash_error_code ) ) == bash_error_code )
    utils.throw( cat( sprintf( "%s", result[ lines ] ), "", sprintf( "%3d:%s", 1:length( commands ), commands ), "", sprintf( "END_%s", bash_error_code ), "",  sep = "\n" ) )

  return( result )
}

##################################################################/
# bash.create.script ####
# runs commands on external host
##################################################################/
bash.create.script = function( commands, fileName = NULL, dir = tempdir() )
{
  # if no filename is given then assign a temporary one
  if( is.null( fileName ) )
    fileName = tempfile( pattern = "commands.", fileext = ".sh", tmpdir = dir )

  # header for all all commands
  bashCommands = c( strrep( "#", 50), "# generated by R Script", strrep( "#", 50), "", "#!/bin/bash", "" )

  # write to file
  fileConn = file( fileName )
  writeLines( c( bashCommands, commands ), fileConn )
  close( fileConn )

  return( fileName )
}

##################################################################/
# bash.submit.poolJob ####
# runs a script
##################################################################/
bash.submit.poolJob = function(
  # location of script to run
  file,
  dirExternal    = default_external_dir,
  externalHost   = default_external_host,

  # job details
  jobName        = NULL,
  clusterQueue   = default_clusterQueue,
  clusterProject = default_clusterProject,
  cores          = 1,
  arrayJobs      = 1,
  hold_jobID     = default_hold_jobID

)
{
  job = bash.job.class$new(
    jobName        = jobName,
    script         = file,
    dirJob         = dirExternal,
    clusterQueue   = clusterQueue,
    clusterProject = clusterProject,
    cores          = cores,
    arrayJobs      = arrayJobs,
    hold_jobID     = hold_jobID
  )
  job$submit()
  return( job )
}

##################################################################/
# bash.uploadFiles ####
# load a file to a remote server
##################################################################/
bash.uploadFiles = function( fileLocal, dirLocal = NULL, dirExternal = default_external_dir, externalHost = default_external_host )
{
  # if directory is specified then require the full path
  if( !is.null( dirLocal ) )
    fullLocal = sprintf( "%s/%s", dirLocal, fileLocal )
  else
    fullLocal = fileLocal

  # if specify multiple files then concat
  if( length( fileLocal ) > 1 )
    fileLocal = paste( fileLocal, sep = " " )

  return( system( sprintf( "scp %s %s:%s/", fullLocal, externalHost, dirExternal ) ) )
}

##################################################################/
# bash.downloadFiles ####
# load a file to a remote server
##################################################################/
bash.downloadFiles = function( fileExternal, dirExternal = default_external_dir, dirLocal = NULL, externalHost = default_external_host )
{
  # if directory is specified then require the full path
  if( fileExternal[ 1 ] == "*" )
    fullExternal = dirExternal
  if( !is.null( dirExternal ) )
    fullExternal = sprintf( "%s/%s", dirExternal, fileExternal )
  else
    fullExternal = fileExternal

  # if specify multiple files then concat
  if( length( fullExternal ) > 1 )
    fullExternal = paste( fullExternal, sep = " " )

  ret = list()
  for( idx in 1:length( fullExternal ))
    ret[[ idx ]] = system( sprintf( 'scp %s:"%s" %s/', externalHost, fullExternal[ idx ], dirLocal ) )

  return( ret )
}

##################################################################/
# bash.execute.script ####
# runs commands on external host
##################################################################/
bash.execute.script = function(
  fileExternal,
  dirExternal  = default_external_dir,
  externalHost = default_external_host,
  dirLocal     = NULL,
  local        = FALSE

)
{
  if( local == FALSE )
  {
    commands = c()
    if( !is.null( dirExternal ) )
      commands = bash.cd( commands, dirExternal )
    commands = c(
      commands,
      sprintf( "chmod u+x %s", fileExternal ),
      sprintf( "./%s", fileExternal )
    )
  }
  else
  {
    commands = c()
    if( !is.null( dirLocal ) )
      commands = bash.cd( commands, dirLocal )
    commands = c(
      commands,
      sprintf( "chmod u+x %s", fileExternal ),
      fileExternal
    )
  }
  return( bash.execute.commands( commands, externalHost = externalHost, local = local ) )
}

##################################################################/
# bash.execute.Rcommand ####
# runs Rcommands on external host or pool
##################################################################/
bash.execute.Rcommand = function(
  Rcommand,
  jobName        = "test",                # base of the job name (has date/time added to it)
  dirExternal    = default_external_dir,  # directory where the R session is run and output is writtend
  externalHost   = default_external_host, # the host on which it runs
  local          = FALSE,                 # run the command locally (in the local directory)
  onPool         = TRUE,                  # run the job on the pool
  clusterQueue   = default_clusterQueue,


  clusterProject = default_clusterProject,
  arrayJobs      = 1,                     # run multiple arrag jobs, the job number is the first and only Arg passed to RScript
  cores          = 1,
  hold_jobID     = default_hold_jobID,
  # create a job object even if we are only calculating local to deal with full name
    job            = bash.job.class$new(
    jobName        = jobName,
    script         = "# empty script",
    dirJob         = dirExternal,
    clusterQueue   = clusterQueue,
    clusterProject = clusterProject,
    arrayJobs      = arrayJobs,
    cores          = cores,
    hold_jobID     = hold_jobID
  )
)
{
  # create the file names based upon the given job name and the current time
  fileRoot   = job$jobFullName
  fileR      = sprintf( "%s.R",  job$jobFullName  )
  fileSh     = sprintf( "%s.sh", job$jobFullName )
  fileShFull = sprintf( "%s/%s", job$dirLocal, fileSh )


  # write the R file locally
  fileRLocal = sprintf( "%s/%s", job$dirLocal, fileR )
  fileRExt   = sprintf( "%s/%s", dirExternal, fileR )
  fileConn = file( fileRLocal )
  writeLines( Rcommand, fileConn )
  close( fileConn )

   # make bash script to execute command
  if( local == FALSE )
  {
    if( onPool == TRUE )
      command = ifelse( arrayJobs == 1, sprintf( "Rscript %s", fileRExt  ), sprintf( "Rscript %s $SGE_TASK_ID", fileRExt  ) )
    else
      command = sprintf( "Rscript %s", fileR )
  }
  else
    command = sprintf( "Rscript %s", fileRLocal )

  if( local == FALSE )
  {
     # upload R file to the external host
    bash.uploadFiles( fileR, dirLocal = job$dirLocal, dirExternal = dirExternal, externalHost = externalHost )

    # update the script to run with the new command and submit
    if( onPool == TRUE )
    {
      job$updateScript( command )
      job$submit()
      r = job
    }
    else
    {
      bash.create.script( command, fileName = fileShFull )
      bash.uploadFiles( fileSh, dirLocal = job$dirLocal, dirExternal = dirExternal, externalHost = externalHost )
      r = bash.execute.script( fileSh, dirExternal = dirExternal, externalHost = externalHost )
    }
  }
  else
  {
    bash.create.script( command,  fileName = fileShFull )
    r = bash.execute.script( fileShFull, local = TRUE )
  }

  return( r )
}

##################################################################/
# bash.execute.Rfunction ####
# runs Rfunction  external host or pool
##################################################################/
bash.execute.Rfunction = function(
  Rfunction,
  jobName        = "test",                # base of the job name (has date/time added to it)
  dirExternal    = default_external_dir,  # directory where the R session is run and output is writtend
  externalHost   = default_external_host, # the host on which it runs
#  local          = FALSE,                 # run the command locally (in the local directory)
  onPool         = TRUE,                  # run the job on the pool
  clusterQueue   = default_clusterQueue,
  clusterProject = default_clusterProject,
  arrayJobs      = 1,                     # run multiple arrag jobs, the job number is the first and only Arg passed to RScript
  cores          = 1,
  hold_jobID     = default_hold_jobID
)
{
  # check to see if is of the correct form
  nArgs = length( formalArgs( Rfunction ))
  #if( onPool & arrayJobs > 1 & nArgs != 1 )
  #  utils.throw( "when running a job on the pool Rfunction is a function with a single argument which is the job number" )
  #if( ( !onPool | arrayJobs == 1 ) & nArgs != 0 )
  #  utils.throw( "when running a single job externally then RFunction is a function with zero arguments ")

  # set up a job object to get the name etc
  job            = bash.job.class$new(
    jobName        = jobName,
    script         = "# empty script",
    dirJob         = dirExternal,
    clusterQueue   = clusterQueue,
    clusterProject = clusterProject,
    arrayJobs      = arrayJobs,
    cores          = cores,
    hold_jobID     = hold_jobID
  )

  # work out the RCommand which needs to be executed and the name of the files where the results are stored
  if( onPool == TRUE  )
  {
    if( arrayJobs > 1 )
    { print("1")
      RDataFiles = sprintf( "%s.*.RData", job$jobFullName )
      RCommandTemplate = '
      jobIdx = as.integer( commandArgs(trailingOnly=TRUE)[1] )
      f = %s
      r = f( jobIdx )

      file = sprintf( "%%s/%%s.%%d.RData", "%s", "%s", jobIdx )
      saveRDS( r, file = file )
      '
    }
    else
    { print("2")
      RDataFiles = sprintf( "%s.RData", job$jobFullName )
      RCommandTemplate = '
      f = %s
      r = f()
      file = sprintf( "%%s/%%s.RData", "%s", "%s"  )
      saveRDS( r, file = file )
      '
    }
  }
  else
  { print("3")
    RDataFiles = sprintf( "%s.RData", job$jobFullName )
    RCommandTemplate = '
    f = %s
    r = f()
    file = sprintf( "~/%%s/%%s.RData", "%s", "%s"  )
    saveRDS( r, file = file )
    '
  }
  bits =  capture.output( print( Rfunction ) )
  if( substr( bits[ length( bits) ], 1, 13 ) == "<environment:" )
    bits = bits[ 1:( length( bits) - 1 ) ]

  Rcommand = sprintf( RCommandTemplate, paste( bits, collapse = "\n" ), job$dirJob, job$jobFullName )
  #Remove any last missing bytes (DO NOT USE BYTES IN ANNNY FUNCTION EVER)
  Rcommand = str_replace(Rcommand, "<.*>", "")

  job$outputFiles = RDataFiles
  submittedJob = bash.execute.Rcommand(
    Rcommand,
    jobName,
    dirExternal    = dirExternal,
    externalHost   = externalHost,
    local          = FALSE,
    onPool         = onPool,
    clusterQueue   = clusterQueue,
    clusterProject = clusterProject,
    arrayJobs      = arrayJobs,
    job            = job,
    cores          = cores,
    hold_jobID     = hold_jobID
  )
  if( onPool == TRUE )
    return( submittedJob )
  else
  {
    bash.downloadFiles( RDataFiles, dirExternal = job$dirJob, dirLocal = job$dirLocal )
    res = readRDS( sprintf( "%s/%s", job$dirLocal, RDataFiles ) )
    return( res )
  }
}

##################################################################/
# bash.update.Rpackage ####
# builds a local RPackage to a source file and updates
##################################################################/
bash.update.Rpackage = function(
  packageName,
  sourcePackagePath   = "~/Desktop/Oxford",
  externalPackagePath = "myPackages",
  externalHost        = default_external_host
)
{
  # build the source package
  package = devtools::build( pkg = sprintf( "%s/%s", sourcePackagePath, packageName ), path = sourcePackagePath )

  # upload the package
  bash.uploadFiles( package, dirExternal = externalPackagePath )

  # build the package externally
  #browser()
  command = sprintf( "R CMD INSTALL --no-multiarch %s/%s", externalPackagePath, basename( package ) )
  r = bash.execute.commands( command )
  return( r )
}

##################################################################/
# bash.jobs.get ####
# gets all
##################################################################/
bash.jobs.get = function(
  jobName        = "*",                     # base of the job name or * for all
  date           = format( Sys.time(), "%Y%m%d"), # date filter of the form 20190913 or * for all
  dirLocal       = tempdir(),               # local place to download files to
  dirExternal    = default_external_dir,    # directory where the R session is run and output is writtend
  externalHost   = default_external_host    # the host on which it runs
)
{
  # see if there are any files
  filePath  = sprintf( "%s*%s*.jobObject", jobName, date )
  command  = sprintf( "ls %s/%s", dirExternal, filePath )
  files    = bash.execute.commands( command, externalHost = externalHost )

  jobs = list()
  if( length( files ) )
  {
      bash.downloadFiles( filePath, dirExternal = dirExternal, dirLocal = dirLocal, externalHost = externalHost )
      localFiles = str_replace_all( files, dirExternal, dirLocal )
      for( idx in 1:length( localFiles ) )
      {
        jobData       = fread( localFiles[ idx ] )
        jobs[[ idx ]] = bash.job.class$new( jobObject = jobData )
      }
  }

  return( jobs )
}
