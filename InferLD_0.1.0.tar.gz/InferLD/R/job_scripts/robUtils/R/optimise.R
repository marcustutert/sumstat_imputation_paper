###################################################################/
# Name:       utils.optimise.vectorized
# Descrption: vectorized version of the Brent Minimisation algorithm
#             useful for when solving many similar optimization problems
#             where evaluation of the objective can be calculated far more
#             efficiently when vectorized
# Args:       f  - function to optimize over with single input (vector) and outputs a vector of values
#             a  - vector of left hand boundary
#             v  - vector of best initial guesses
#             b  - vector of right hand boundary
# Return:     TRUE/FALSE
###################################################################/
utils.optimise.vectorized = function( f, a, v, b, tol = 1e-6, maximum = F, itmax = 50 )
{
  # constants
  cgold = 0.3819660
  zeps  = 1e-10

  # initial data check
  if( sum( a > v ) > 0 | sum( v > b ) > 0 )
    stop( "The initial value and boundary must saisfy a<v<b" );

  lv = length( v )
  if( length( a ) != lv | length( b ) != lv )
    stop( "The initial value and boundaries must be of the same length" )

  # initial set up
  w = v
  x = v
  e = 0
  d = 0
  fx = f( x )
  if( maximum )
    fx = -fx
  fv = fx
  fw = fx

  # check the function return
  if( length( fx ) != lv )
    stop( "The initial value and function return must be of the same length")
  # main loop
  for( iter in 1:itmax )
  {
    xm   = 0.5 * ( a + b )

    # stop when all are good, calculate relative tolerances
    tol1 = tol * abs( x ) + zeps
    tol2 = tol1 * 2
    if( sum( abs( x - xm ) > ( tol2 - 0.5 * ( b - a ) ) ) == 0 )
      break

    # fit parabola for all
    r = ( x - w ) * ( fx - fv )
    q = ( x - v ) * ( fx - fw )
    p = ( x - v ) * q - ( x - w ) * r
    q = 2 * ( q - r )
    p = -p * sign( q )
    q = abs( q )
    etemp =e
    e  = d
    dd = p / ( q + zeps );  # avoid divide by 0
    u  = x + dd
    d  = dd + ( u - a < tol2 | b - u < tol2 ) * ( ( xm - x > 0 ) * tol - dd )

    # next find golden ratio point
    eg = -x + a + ( x < xm ) * ( b - a )
    dg = eg * cgold

    # decide whether to pick the paroabola  min or golden ratio point
    absEtemp = abs( etemp )
    gr = ( absEtemp > tol1 )  & ( 2 * abs( p ) < q *  absEtemp ) & ( dd > (a-x) ) & ( dd < ( b - x ) )
    e  = eg + gr * ( e -eg)
    d  = dg + gr * ( d - dg )

    # move to the next point, if distance is smaller than tolerance then move by tolerance
    u = x + d + ( abs( d ) < tol1 ) * ( sign( d ) * tol1 - d )

    # single function evaluation at next point
    fu = f( u )
    if( maximum )
      fu = - fu

    # finally book-keeping to see which point to update
    cond1 = fu >= fx
    cond2 = u < x
    cond3 = fu > fw & w != x
    cond4 = cond1 | cond2
    cond5 = !( cond1 & cond2 )
    cond6 = cond1 | !cond2
    cond7 = !cond1 | cond2
    cond8 = cond1 & cond3

    a  = x + cond4 * ( -x + u + cond5 * ( a - u ) )
    b  = x + cond6 * ( -x + u + cond7 * ( b - u ) )
    v  = w + cond8 * ( u - w )
    fv = fw + cond8 * ( fu - fw )
    w  = x + cond1 * ( -x + u + cond3 * ( w -u ) )
    fw = fx + cond1 * ( -fx + fu + cond3 * ( fw -fu ) )
    x  = u + cond1 * ( -u + x )
    fx = fu + cond1 * ( -fu + fx )
  }
  if( maximum )
    return( list( maximum = x, objective = - fx ) )
  else
    return( list( minimum = x, objective = fx ) )
}
