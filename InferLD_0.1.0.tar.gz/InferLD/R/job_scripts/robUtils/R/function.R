###################################################################################/
# utils.function.piecewiselinear
#
# piecewise linear approxiximation between nodes with constant extrapolation out
# of range
#
# scalable to quick for large number of x points and nodes using data.table roll join
# note the method is not optimized for asking for single values of x
###################################################################################/
utils.function.piecewiselinear = function(
  x,
  xnodes,
  ynodes
)
{
  if( length( xnodes ) != length( ynodes ) )
    utils.throw( "xnodes and ynodes must be the same length" )

  if( length( xnodes ) != length( unique( xnodes ) ) )
    utils.throw( "xnodes must be unique" )

  # put nodes in to a data.table
  dt = data.table( xnode = xnodes, ynode = ynodes )[ order( xnode ) ]

  # calculate the gradient between nodes
  dt[ , delta := ifelse( is.na( shift( xnode, 1, type = "lead" ) ), 0,  ( shift( ynode, 1, type = "lead" ) - ynode ) / ( shift( xnode, 1, type = "lead" ) - xnode ) ) ]

  # now label the points
  x = data.table( xnode = x, x = x, label = 1:length( x ) )

  # use the roll join to find all points in O(n+m) time
  y = dt[ x, on = "xnode", roll = TRUE][ , .( label, y = ynode + ( x - xnode ) * delta ) ]
  utils.data.table.replaceNA( y, "y", value = dt[ 1, ynode ] )

  return( y[ order( label ) ][ , y ] )
}
