if( !exists( "logEnv" ) )
{
  logEnv = new.env()
  assign( "logOn", FALSE, envir = logEnv )
}

##################################################################/
# Name:        utils.log.logging
# Description: function to turn on logging
###################################################################/
utils.log.logging = function( on = NULL )
{
  if( is.null( on  ) )
    return( get( "logOn", envir = logEnv ) )
  else
  if( on %in% c( TRUE, FALSE ) )
    assign( "logOn", on, envir = logEnv )
  else
    utils.throw( "on must be TRUE/FALSE or NULL of status")
}

##################################################################/
# Name:        utils.log
# Description: function to log, print to the screen if required
###################################################################/
utils.log = function( message )
{
  if( get( "logOn", envir = logEnv ) == T )
    cat( message )
}
