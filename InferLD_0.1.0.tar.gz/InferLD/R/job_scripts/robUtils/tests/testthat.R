library(testthat)
library(robUtils)

test_check("robUtils")
