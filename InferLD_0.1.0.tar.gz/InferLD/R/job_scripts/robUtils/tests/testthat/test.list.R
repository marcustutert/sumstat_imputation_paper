###################################################################
# Description: test list.namedListToChar
###################################################################
list = list( a = "b", c = "d", e = "f" )
test_that( "Test list.namedListToChar", expect_equal( utils.list.namedListToChar( list ), "a¶c¶e¶b¶d¶f" ) )
list = list( a = 1, b = 2, c = 3 )
test_that( "Test list.namedListToChar", expect_equal( utils.list.namedListToChar( list ), "a¶b¶c¶1¶2¶3" ) )

###################################################################
# Description: test list.charToNamefList
###################################################################
list = list( a = "b", c = "d", e = "f" )
test_that( "Test list.charTonamedList", expect_equal( utils.list.charToNamedList( utils.list.namedListToChar( list ), type = "character" ) , list ) )
list = list( a = 1, b = 2, c = 3 )
test_that( "Test list.charTonamedList", expect_equal( utils.list.charToNamedList( utils.list.namedListToChar( list ), type = "double" ) , list ) )
list = list( a = 1, b = 2, c = "a" )
test_that( "Test list.charTonamedList", expect_equal( utils.list.charToNamedList( utils.list.namedListToChar( list ) ) , list ) )
