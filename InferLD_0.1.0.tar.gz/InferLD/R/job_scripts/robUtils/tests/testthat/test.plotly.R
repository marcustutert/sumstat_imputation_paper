library( robUtils )
library( data.table )

###################################################################
# Description: test utils.plotly.scatter.genomic
###################################################################
data = data.table( chrom = sample( c( "chr1", "chr2" ), 1e3, replace = T ), pos = 1:1e3, x = runif( 1:1e3), y = runif( 1:1e3 ))
scatter1 = utils.plotly.scatter.genomic( data, columns = c( "x", "y" ), chromCol = "chrom", posCol = "pos", colorGenomicDist = 10 )
scatter2 = utils.plotly.scatter.genomic( data, columns = c( "x", "y" ), chromCol = "chrom", posCol = "pos", colorGenomicDist = 10 )
comb     = utils.shiny.layout( list( scatter1, scatter2 ) )
utils.plotly.genomic.link( scatter1, scatter2, bothWays = T )
if( F )
  comb$runApp()
###################################################################
# Description: test utils.plotly.track.genomic
###################################################################
track1 = utils.plotly.track.genomic( data, chromCol = "chrom", posCol = "pos", valCol = "x" )
track2 = utils.plotly.track.genomic( data, chromCol = "chrom", posCol = "pos", valCol = "x" )
comb     = utils.shiny.layout( list( track1, track2 ) )
utils.plotly.genomic.link( track1, track2, bothWays = T )
if( F )
  comb$runApp()
###################################################################
# Description: test track and scatter
###################################################################
scatter = utils.plotly.scatter.genomic( data, columns = c( "x", "y" ), chromCol = "chrom", posCol = "pos", colorGenomicDist = 10 )
track   = utils.plotly.track.genomic( data, chromCol = "chrom", posCol = "pos", valCol = "x", defaultWidth = 10, initialPosMin = 0, initialPosMax = 100 )
comb    = utils.shiny.layout( list( scatter, track ) )
utils.plotly.genomic.link( scatter, track, bothWays = T )
if( F )
  comb$runApp()
