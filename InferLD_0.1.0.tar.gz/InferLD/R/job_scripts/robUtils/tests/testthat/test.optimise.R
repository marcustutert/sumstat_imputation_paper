library( robUtils )
library( testthat )

###################################################################
# Description: test utils.optimise.vectorized
###################################################################
N = 1e3;
k = runif( N, min = 10, max = 100 )
f = function( x)
  return( -k * log( x ) + x )

# add some noise around boundary and mid points
left   = runif( N, min = 0.3 * k, max = 0.6 * k  )
mid    = runif( N, min = 0.6* k, max = 1.8 * k  )
right  = runif( N, min = 1.8* k, max = 2.5 * k  )

tol = 1e-6
res = utils.optimise.vectorized( f, left, mid, right, tol = tol  )
test_that( "Optimized x values are in tolerance, tolerances is 1e-6", expect_lt( max( abs( res$minimum / k - 1 ) ), tol * 2 ) )
test_that( "Optimized functions values are in tolerance, tolerances is 1e-6", expect_lt( max( abs( res$objective + k * log( k ) - k ) ), tol * 2 ) )

tol = 1e-5
res = utils.optimise.vectorized( f, left, mid, right, tol = tol  )
test_that( "Optimized x values are in tolerance, tolerances is 1e-5", expect_lt( max( abs( res$minimum / k - 1 ) ), tol * 2 ) )
test_that( "Optimized functions values are in tolerance, tolerances is 1e-5", expect_lt( max( abs( res$objective + k * log( k ) - k ) ), tol * 2 ) )

tol = 1e-4
res = utils.optimise.vectorized( f, left, mid, right, tol = tol  )
test_that( "Optimized x values are in tolerance, tolerances is 1e-4", expect_lt( max( abs( res$minimum / k - 1 ) ), tol * 2 ) )
test_that( "Optimized functions values are in tolerance, tolerances is 1e-4", expect_lt( max( abs( res$objective + k * log( k ) - k ) ), tol * 2 ) )

# test maximum
f = function( x)
  return( k * log( x ) - x )
tol = 1e-6
res = utils.optimise.vectorized( f, left, mid, right, tol = tol, maximum = T  )
test_that( "Optimized x values are in tolerance, tolerances is 1e-6", expect_lt( max( abs( res$mzimum / k - 1 ) ), tol * 2 ) )
test_that( "Optimized functions values are in tolerance, tolerances is 1e-6", expect_lt( max( abs( res$objective - k * log( k ) + k ) ), tol * 2 ) )
