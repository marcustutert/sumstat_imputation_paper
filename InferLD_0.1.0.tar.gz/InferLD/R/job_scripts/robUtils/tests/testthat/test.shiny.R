###################################################################
# Description: test shiny.getLastEvent
###################################################################
name = "test"
list = list( NULL, NULL, NULL )
test_that( "Test shiny.getLastEvent", expect_equal( utils.shiny.getLastEvent( list, name ), NULL ) )
list = list( NULL, NULL, "A" )
test_that( "Test shiny.getLastEvent", expect_equal( utils.shiny.getLastEvent( list, name ), list( index = 3, event = "A" ) ) )
list = list( NULL, "B", "A" )
test_that( "Test shiny.getLastEvent", expect_equal( utils.shiny.getLastEvent( list, name ), list( index = 2, event = "B" ) ) )
list = list( NULL, "B", "C" )
test_that( "Test shiny.getLastEvent", expect_equal( utils.shiny.getLastEvent( list, name ), list( index = 3, event = "C" ) ) )
list = list( "D", "B", "C" )
test_that( "Test shiny.getLastEvent", expect_equal( utils.shiny.getLastEvent( list, name ), list( index = 1, event = "D" ) ) )
