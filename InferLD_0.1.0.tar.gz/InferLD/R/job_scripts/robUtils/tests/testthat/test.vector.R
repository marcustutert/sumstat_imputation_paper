###################################################################
# Description: test groupSum
###################################################################
vector   = 1:100
expected = c( 55, 155, 255, 355, 455, 555, 655, 755, 855, 955 )
test_that( "Test groupSum", expect_equal( utils.vector.groupSum( vector, 10 ), expected) )

###################################################################
# Description: test groupSum interweaved
###################################################################
expected = c( 460, 470, 480, 490, 500, 510, 520, 530, 540, 550 )
test_that( "Test groupSum", expect_equal( utils.vector.groupSum( vector, 10, interweaved = TRUE ), expected) )
