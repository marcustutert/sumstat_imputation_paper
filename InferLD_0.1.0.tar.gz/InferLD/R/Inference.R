#' @export
LD_inference = function(ref_panel_haplotypes,
                         fst,
                         alpha,
                         nSamples,
                         weights_resolution,
                         likelihood_toggle,
                         gwas_variance,
                         case_control_constant,
                         BurnIn,
                         debug){

  #First get the constants that we need
  ref_panel_haplotypes = as.matrix(ref_panel_haplotypes)
  nsnps = ncol(ref_panel_haplotypes)
  nhaps = nrow(ref_panel_haplotypes)

  #Store the results from the gibbs sampler
  results    = gibbs_sampler( nSamples              = nSamples,
                              weights_resolution    = weights_resolution,
                              ref_allele_matrix     = ref_panel_haplotypes,
                              fst                   = fst,
                              alpha                 = alpha,
                              likelihood            = likelihood_toggle,
                              gwas_variance         = gwas_variance,
                              case_control_constant = case_control_constant,
                              debug                 = debug)

  #Specific results we can store
  Gibbs_Array    = results$Gibbs_Array
  likelihood     = results$log_likelihood
  allele_freq    = results$inferred_af_given_weights

  #Store constants
  nsnps = ncol(ref_panel_haplotypes)
  nhaps = nrow(ref_panel_haplotypes)
  #Save data storage/time by only keeping the last 10% of the HW array
  Gibbs_Results_Posterior = Gibbs_Array[,(0.9*ncol(Gibbs_Array)):ncol(Gibbs_Array)]
  #Get the average of the weights
  average_weights = rowMeans(Gibbs_Results_Posterior, na.rm = T)
  #Calculate the LD from the post burn-in samples
  LD  = cov.wt(x = ref_panel_haplotypes, wt = average_weights, cor = T)
  return(list("Gibbs_Array"               = Gibbs_Array,
              "log_likelihood"            = likelihood,
              "inferred_af_given_weights" = allele_freq,
              "LD"                        = LD))
}
