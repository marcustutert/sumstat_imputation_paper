# #!/usr/bin/env Rscript
#
# ## change directory to one up from scripts, no matter how this was called
# args <- commandArgs(trailingOnly = FALSE)
# for(key in c("--file=", "--f=")) {
#     i <- substr(args, 1, nchar(key)) == key
#     if (sum(i) == 1) {
#         script_dir <- dirname(substr(args[i], nchar(key) + 1, 1000))
#         setwd(file.path(script_dir, "../../"))
#     }
# }
#
# pkg <- "InferLD"
# root_dir <- getwd()
# devtools::document(pkg)
# devtools::build(pkg = pkg)
# devtools::load_all(pkg, quiet = FALSE)
# package_tarball <- devtools::build(pkg = pkg, manual = TRUE)
# install.packages(package_tarball, repos = NULL, type ="source")
